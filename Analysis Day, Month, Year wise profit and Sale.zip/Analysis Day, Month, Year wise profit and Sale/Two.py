import streamlit as st

def main():
    st.title("Dataset Analysis")
    st.write("Welcome!")
    

    
if __name__ == "__main__":
    main()
