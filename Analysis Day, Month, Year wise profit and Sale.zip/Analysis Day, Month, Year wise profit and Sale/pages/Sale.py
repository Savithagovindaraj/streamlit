import streamlit as st
import pandas as pd

def MONTH(data):
    sales_by_year = data.groupby('Month')['Selling price'].sum().reset_index()
    st.title('Sales by Month')
    st.bar_chart(sales_by_year.set_index('Month'))
    st.text_area("Comment of Month",max_chars=500)
    st.markdown("This Chart will gives sale by month")

def YEAR(data):
    sales_by_year = data.groupby('Year')['Selling price'].sum().reset_index()
    st.title('Sales by Year')
    st.bar_chart(sales_by_year.set_index('Year'))
    st.text_area("Comment of Year",max_chars=500)
    st.markdown("This Chart will gives sale by year")
    
def DAY(data):
    sales_by_year = data.groupby('Day')['Selling price'].sum().reset_index()
    st.title('Sales by Day')
    st.bar_chart(sales_by_year.set_index('Day'))
    st.text_area("Comment of Day",max_chars=500)
    st.markdown("This Chart will gives sale by day")


@st.cache_data
def readdata(dataset):
    data = pd.read_csv(dataset)
    st.session_state.data = data
    return data

def main():
    st.header("Dataset Analysis")
    st.subheader("Yearly Sale Revenue Projections Table and Chart")
    dataset = st.file_uploader("Our Dataset",type='csv')
    if dataset:
        data = readdata(dataset)
        data['datetime_column'] = pd.to_datetime(data['Sale date'])
        data['Day'] = data['datetime_column'].dt.day
        data['Month'] = data['datetime_column'].dt.month
        data['Year'] = data['datetime_column'].dt.year    

        Daa,Chart=st.columns(2)
        with Daa:
            Daa.subheader("Select the Checkbox",divider='rainbow')
            #st.write(data)
            if dataset:
                #data = readdata(dataset)
                syear,smonth,sday = st.columns(3)
                with syear:
                    Box1 = st.checkbox(" ",help = 'Sale by Day')
                with smonth:
                    Box2 = st.checkbox(" ",help = 'Sale by Month')
                with sday:
                    Box3 = st.checkbox(" ",help = 'Sale by Year')
        with Chart:
            Chart.subheader("Our Table corresponding Charts",divider='rainbow')
            data['datetime_column'] = pd.to_datetime(data['Sale date'])
            data['Day'] = data['datetime_column'].dt.day
            data['Month'] = data['datetime_column'].dt.month
            data['Year'] = data['datetime_column'].dt.year 
            if Box1: 
                DAY(data)
            if Box2: 
                MONTH(data)
            if Box3:
                YEAR(data)
                
            
            
if __name__ == '__main__':
    main()
