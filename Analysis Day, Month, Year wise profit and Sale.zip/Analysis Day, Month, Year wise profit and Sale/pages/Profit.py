import streamlit as st
import pandas as pd
import datetime as dt
import matplotlib.pyplot as plt


def Year(data):
    sales_by_year = data.groupby('year')['Cost Price'].sum().reset_index()
    st.title('Cost Price by year')
    st.bar_chart(sales_by_year.set_index('year'))
    st.text_area("Comment of year",max_chars=500)
    st.markdown("This Chart will gives sale by year")

def Month(data):
    sales_by_year = data.groupby('month')['Cost Price'].sum().reset_index()
    st.title('Cost Price by month')
    st.bar_chart(sales_by_year.set_index('month'))
    st.text_area("Comment of month",max_chars=500)
    st.markdown("This Chart will gives sale by month")

def Day(data):
    sales_by_year = data.groupby('day')['Cost Price'].sum().reset_index()
    st.title('Cost price by Day')
    st.bar_chart(sales_by_year.set_index('day'))
    st.text_area("Comment of Day",max_chars=500)
    st.markdown("This Chart will gives sale by day")

    

def main():
    st.header("Dataset Analysis")
    st.subheader("Profit Chart",divider='rainbow')
    # Retrieve data from session state
    if 'data' in st.session_state:
        data = st.session_state.data
        #st.write("Data from Page 3 (accessed in Page 2):", data)
        data['datetime_column'] = pd.to_datetime(data['Sale date'])
        data['day'] = data['datetime_column'].dt.day
        data['month'] = data['datetime_column'].dt.month
        data['year'] = data['datetime_column'].dt.year
        
        box,chart=st.columns(2)   
        with box:
            syear,smonth,sday = st.columns(3)
            with syear:
                Box1 = st.checkbox(" ",help = 'Profit by Day')
            with smonth:
                Box2 = st.checkbox(" ",help = 'Profit by Month')
            with sday:
                Box3 = st.checkbox(" ",help = 'Profit by Year')    
        with chart:
            #if data:
            if Box1: 
                Day(data)
            if Box2: 
                Month(data)
            if Box3:
                Year(data)
    else:
        st.write("No data imported in the Sale Page")

if __name__ == '__main__':
    main()
